import art
print(art.art("woman"))
print(art.art("coffee"))
print(art.art("random"))
print(art.art("random"))
print(art.art("random"))
print(art.art("random"))


print(art.text2art("Hello"))


