# import random as rand
# rand.randint(1,6)
# 3

from random import randint
randint(1,6)

from math import pi, sin
pi 
