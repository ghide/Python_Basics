from translate import Translator
translator= Translator(to_lang="es")
translation = translator.translate("Hello, I love you")
print(translation)
