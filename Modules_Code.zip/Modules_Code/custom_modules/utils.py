brand_colors = ('#e63946','#f1faee', '#a8dadc', '#1d3557')

def mean(nums):
    return sum(nums)/len(nums)
