from utils import mean

mean([1])
