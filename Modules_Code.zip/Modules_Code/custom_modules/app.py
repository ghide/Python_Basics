from utils import brand_colors, mean

print(brand_colors)
print(mean([1,2,3,4,5,6,7,99]))
