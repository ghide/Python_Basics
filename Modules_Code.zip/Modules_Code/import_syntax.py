from math import sin,pi
sin(1)
print(pi)
