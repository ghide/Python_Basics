
for char in "OCTOPUS":
    color = "magenta"
    print(char)

if True:
    animal = "Osprey"

print("AFTER LOOP", color)
print("AFTER CONDITIONAL", animal)
print(char)

