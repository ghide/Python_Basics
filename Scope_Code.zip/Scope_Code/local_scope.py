
def zoo():
    animal = "Harlequin Shrimp"
    number = 77
    print("INSIDE ZOO FUNCTION: ", animal)

zoo()
print("OUTSIDE FUNCTION: ", animal)
number + 1

