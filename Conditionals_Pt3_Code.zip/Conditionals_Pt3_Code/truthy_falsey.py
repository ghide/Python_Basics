color = input("enter a color: ")
if color:
    print(f"{color} is my favorite color too!")

# Another example
num_lives = 0
if num_lives:
    print("STILL PLAYING THE GAME!")
else:
    print("GAME OVER, OUT OF LIVES!")
