fav_color = "green"
fav_movie = "amadeus"
fav_food = "pizza"

if fav_color == "green":
    print("I love green too!")
    if fav_movie == "amadeus":
        print("I love Amadeus too!")
        if fav_food == "pasta":
            print("I love pasta too!")

