#INVALID INDENTATION!!
# mood = 'devestated'

# if mood == 'happy':
#         print("I'm happy you are happy!") 
#     print(":) " * 10)
# elif mood == 'sad':
#     print("I'm sorry that sucks :( ")
# else:
#     print("I dont know that mood!")

# Valid Indentation
mood = 'devestated'

if mood == 'happy':
    print("I'm happy you are happy!")
    print(":) " * 10)
elif mood == 'sad':
    print("I'm sorry that sucks :( ")
else:
    print("I dont know that mood!")

