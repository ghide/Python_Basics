from random import randint

rand = randint(0,1)
if rand == 0:
    print("HEADS!")
else:
    print("TAILS!")
