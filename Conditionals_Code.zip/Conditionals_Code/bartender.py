age = input("How old are you? ")
age = int(age)

if age >= 21:
    print("Come on in!")
    print("*************")
else:
    print("Go home kid!")
    print("*************")
    print("*************")
    print("*************")

print("AFTER THE IF STATEMENT")
