# color = "black"
color = 22

if color == "green":
    print("BEGINNER!")
elif color == "blue":
    print("INTERMEDIATE")
elif color == "black":
    print("ADVANCED")
else:
    print("I HAVE NO IDEA WHAT YOU ARE TALKING ABOUT!!!!")
