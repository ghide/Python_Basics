for outer in range (1,5):
    print(outer)
    for inner in range (1,10):
        print("\t", inner)
