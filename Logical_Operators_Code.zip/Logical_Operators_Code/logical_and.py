age = 20
if age > 18 and age < 21:
    print("You can enter the venue but cannot drink.")

# Could also be written using nested conditionals:
# if age > 18:
#     if age < 21:
#         print("You can enter the venue but cannot drink.")
